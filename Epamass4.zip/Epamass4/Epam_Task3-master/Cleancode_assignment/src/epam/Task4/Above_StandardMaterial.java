package epam.Task4;

public class AboveStandardMaterial extends TotalCost{

	@Override
	void getcostpersqarefeet() {
		// TODO Auto-generated method stub
		cost=1500;
		
	}
	

}
