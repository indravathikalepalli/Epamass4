package epam.Task4;

public class StandardMaterial extends TotalCost {

	@Override
	void getcostpersqarefeet() {
		// TODO Auto-generated method stub
		cost=1200;
	}

	
}
