package epam.Task4;

public class SimpleService {

	public String  helloService(String msg){
		return "Hello "+ msg;
	}
}
