package epam.Task4;

public class HIghStandardandFullAutomatic extends TotalCost{

	@Override
	void getcostpersqarefeet() {
		// TODO Auto-generated method stub
		cost=2500;
		
	}
	

}
