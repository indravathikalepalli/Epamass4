# Epam_Task3
Clean code assignment consists of java files and JUNIT test files for respective classes
